rm *.aux *.blg *.log *.gz *.bbl *.dpth *.lot *.toc *.lof *.idx *.auxlock *.dvi *.brf *.out comment.cut
%rm *.pdf
